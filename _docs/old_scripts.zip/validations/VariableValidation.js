const Variable = {
    "id": "/VariableValidation",
    "type": Object,
    "properties": {
        "description": { "type": "string" },
    },
    "required": ["description"]
};

module.exports = Variable;